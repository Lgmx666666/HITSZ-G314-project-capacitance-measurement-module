#ifndef ___PCAP04_H___
#define ___PCAP04_H___

void PCap04_Test(void);
void PCap04_PowerON_RESET(void);
void PCap04_Init(void);
void PCap04_writeFirmware(void);
void PCap04_CDCStart(void);
void PCap04_writeConfig(void);
void PCap04_ReadResult(void);

#endif